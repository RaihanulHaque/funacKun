from django.shortcuts import render
from .sortCoordinates import getSortedArray
from .forms import ImageForm
from .models import Image
from django.conf import settings
from skimage.morphology import skeletonize
import numpy as np
from PIL import Image
from json import dumps

# Create your views here.


def home(request):
    if request.method == "POST":
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            # imageName = str(request.FILES['image'].name)
            image1 = request.FILES['image']
            # imageURL = settings.MEDIA_URL + "images/" + imageName
            coordinates = getSortedArray(image1)
            jsonArray = dumps(np.asarray(coordinates).tolist())
            print(jsonArray)
    form = ImageForm()
    return render(request, 'home.html', {'form': form})
