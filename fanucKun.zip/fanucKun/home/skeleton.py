import cv2
from skimage.morphology import skeletonize
from skimage.color import rgb2gray
from PIL import Image
import numpy as np


def getSkeleton(image):
    image = Image.open(image)
    arr = np.array(image)
    image = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
    resizedImage = cv2.resize(image, (600, 600))

    ret, invertedBinimage = cv2.threshold(
        resizedImage, 127, 255, cv2.THRESH_BINARY_INV)  # Invert the binary image
    # perform skeletonization
    skeleton = skeletonize(invertedBinimage)
    # skeleton = invertedBinimage
    # Coordinate Store in list
    coordinates = []
    for y in range(0, skeleton.shape[0]):
        for x in range(0, skeleton.shape[1]):
            if skeleton[y][x][0] == 0 and skeleton[y][x][1] == 255 and skeleton[y][x][2] == 0:
                coordinates.append([x, y])
    return coordinates
