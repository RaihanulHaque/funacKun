from django.shortcuts import redirect, render,HttpResponse
from requests import request
from .sortCoordinates import getSortedArray
from .forms import ImageForm
from .models import Image
from django.conf import settings
from skimage.morphology import skeletonize
import numpy as np
from PIL import Image
from json import dumps

# Create your views here.
array = []
def home(request):
    if request.method == "POST":
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            global array;
            # imageName = str(request.FILES['image'].name)
            image = request.FILES['image']
            # imageURL = settings.MEDIA_URL + "images/" + imageName
            coordinates = getSortedArray(image)
            array = dumps(np.asarray(coordinates).tolist())
    form = ImageForm()
    return render(request, 'home.html', {'form': form})

def coordinates(request):
    # array = [[10,11],[10,12],[10,13][10,14],[10,15],[10,16],[10,17]]
    if(len(array)>0):
        return render(request,'coordinates.html', {'array':array})
    else:
        return redirect('home')